'use strict';

const db = require('../config/db');
const { generateRoomCode } = require('../utils/code');

async function createRoom({ hostId, topic, languageFocus }) {
  let code;
  for (let i = 0; i < 10; i++) {
    code = generateRoomCode();
    const existing = await db.query('SELECT id FROM rooms WHERE room_code = ?', [code]);
    if (!existing.length) break;
  }
  const result = await db.query(
    `INSERT INTO rooms (room_code, host_id, topic, language_focus, status) VALUES (?, ?, ?, ?, 'waiting')`,
    [code, hostId, topic || null, languageFocus || null]
  );
  const rooms = await db.query('SELECT * FROM rooms WHERE id = ?', [result.insertId]);
  return rooms[0];
}

async function getRoomByCode(code) {
  const rooms = await db.query(
    `SELECT r.*, h.display_name as host_name, h.avatar_color as host_color,
            g.display_name as guest_name, g.avatar_color as guest_color
     FROM rooms r
     LEFT JOIN users h ON r.host_id = h.id
     LEFT JOIN users g ON r.guest_id = g.id
     WHERE r.room_code = ?`,
    [code]
  );
  return rooms[0] || null;
}

async function joinRoom(code, userId) {
  const room = await getRoomByCode(code);
  if (!room) {
    const err = new Error('Room not found');
    err.status = 404;
    throw err;
  }
  if (room.status === 'ended') {
    const err = new Error('Room has ended');
    err.status = 410;
    throw err;
  }
  if (room.host_id === userId) {
    return room;
  }
  if (room.guest_id && room.guest_id !== userId) {
    const err = new Error('Room is full');
    err.status = 409;
    throw err;
  }
  await db.query(
    `UPDATE rooms SET guest_id = ?, status = 'active', started_at = COALESCE(started_at, NOW()) WHERE id = ?`,
    [userId, room.id]
  );
  return getRoomByCode(code);
}

async function endRoom(roomId, userId) {
  const rooms = await db.query('SELECT * FROM rooms WHERE id = ?', [roomId]);
  if (!rooms.length) return null;
  const room = rooms[0];
  if (room.host_id !== userId && room.guest_id !== userId) {
    const err = new Error('Not a participant');
    err.status = 403;
    throw err;
  }
  const duration = room.started_at
    ? Math.floor((Date.now() - new Date(room.started_at).getTime()) / 1000)
    : 0;
  await db.query(
    `UPDATE rooms SET status = 'ended', ended_at = NOW(), duration_seconds = ? WHERE id = ?`,
    [duration, roomId]
  );

  // record history for both participants
  if (room.host_id) {
    await db.query(
      `INSERT INTO session_history (room_id, user_id, partner_id, duration_seconds) VALUES (?, ?, ?, ?)`,
      [room.id, room.host_id, room.guest_id, duration]
    );
  }
  if (room.guest_id) {
    await db.query(
      `INSERT INTO session_history (room_id, user_id, partner_id, duration_seconds) VALUES (?, ?, ?, ?)`,
      [room.id, room.guest_id, room.host_id, duration]
    );
  }
  return { ended: true, duration };
}

async function listMyRooms(userId) {
  return db.query(
    `SELECT r.*, h.display_name as host_name, g.display_name as guest_name
     FROM rooms r
     LEFT JOIN users h ON r.host_id = h.id
     LEFT JOIN users g ON r.guest_id = g.id
     WHERE r.host_id = ? OR r.guest_id = ?
     ORDER BY r.created_at DESC
     LIMIT 50`,
    [userId, userId]
  );
}

async function getMessages(roomId) {
  return db.query(
    `SELECT m.*, u.display_name, u.avatar_color
     FROM messages m
     JOIN users u ON m.user_id = u.id
     WHERE m.room_id = ?
     ORDER BY m.created_at ASC
     LIMIT 500`,
    [roomId]
  );
}

async function addMessage(roomId, userId, content) {
  const result = await db.query(
    `INSERT INTO messages (room_id, user_id, content) VALUES (?, ?, ?)`,
    [roomId, userId, content]
  );
  const messages = await db.query(
    `SELECT m.*, u.display_name, u.avatar_color
     FROM messages m JOIN users u ON m.user_id = u.id
     WHERE m.id = ?`,
    [result.insertId]
  );
  return messages[0];
}

module.exports = {
  createRoom, getRoomByCode, joinRoom, endRoom, listMyRooms,
  getMessages, addMessage
};
