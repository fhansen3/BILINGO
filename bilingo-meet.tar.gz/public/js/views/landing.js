(function () {
  'use strict';

  function render(container) {
    container.innerHTML =
      '<div class="app-shell">' +
        '<nav class="navbar-bl">' +
          '<div class="brand"><span class="parrot">🦜</span> BiLingo Meet</div>' +
          '<div class="nav-links">' +
            '<a href="#/login" class="nav-link"><i class="fa-solid fa-right-to-bracket"></i> Entrar</a>' +
            '<a href="#/register" class="btn-bl btn-green btn-sm"><i class="fa-solid fa-user-plus"></i> Crear cuenta</a>' +
          '</div>' +
        '</nav>' +
        '<section class="hero">' +
          '<div class="hero-inner">' +
            '<div>' +
              '<h1>Practica idiomas <span class="accent">cara a cara</span> con el mundo entero</h1>' +
              '<p class="lead">Conéctate por videollamada con hablantes nativos, chatea en tiempo real y mejora tu fluidez sin salir de casa. ¡Gratis y divertido!</p>' +
              '<div class="hero-cta">' +
                '<a href="#/register" class="btn-bl btn-green btn-lg"><i class="fa-solid fa-rocket"></i> Empezar gratis</a>' +
                '<a href="#/login" class="btn-bl btn-outline btn-lg"><i class="fa-solid fa-right-to-bracket"></i> Ya tengo cuenta</a>' +
              '</div>' +
            '</div>' +
            '<div class="hero-art">' +
              '<span class="floating-emoji e1">🇪🇸</span>' +
              '<span class="floating-emoji e2">🇬🇧</span>' +
              '<span class="floating-emoji e3">🇫🇷</span>' +
              '<span class="floating-emoji e4">🇯🇵</span>' +
              '<div class="feature-grid">' +
                '<div class="feature-card green"><i class="fa-solid fa-video"></i><h4>Videollamada HD</h4><p>WebRTC peer-to-peer, sin intermediarios.</p></div>' +
                '<div class="feature-card blue"><i class="fa-solid fa-comments"></i><h4>Chat en vivo</h4><p>Escribe mientras hablas, comparte palabras.</p></div>' +
                '<div class="feature-card orange"><i class="fa-solid fa-globe"></i><h4>+50 idiomas</h4><p>Encuentra hablantes de cualquier idioma.</p></div>' +
                '<div class="feature-card purple"><i class="fa-solid fa-shield"></i><h4>Comunidad segura</h4><p>Modera y reporta con un clic.</p></div>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</section>' +
        '<footer class="app-footer">© BiLingo Meet · Hecho con 💚 para políglotas</footer>' +
      '</div>';
  }

  window.Router.register('landing', render);
})();
