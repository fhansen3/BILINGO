(function () {
  'use strict';

  var ICE_CONFIG = {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' }
    ]
  };

  async function render(container, params) {
    var roomCode = (params.id || '').toUpperCase();
    if (!roomCode) { window.Router.navigate('dashboard'); return; }

    var user = window.Auth.getUser();
    var socket = null;
    var localStream = null;
    var peers = {}; // socketId -> { pc, user, videoEl }
    var audioOn = true;
    var videoOn = true;
    var ended = false;

    container.innerHTML =
      '<div class="app-shell">' +
        '<nav class="navbar-bl">' +
          '<a href="#/dashboard" class="brand" style="text-decoration:none"><span class="parrot">🦜</span> BiLingo Meet</a>' +
          '<div class="nav-links">' +
            '<span class="nav-link"><i class="fa-solid fa-door-open"></i> Sala <strong style="color:var(--green); margin-left:6px">' + window.UI.escapeHtml(roomCode) + '</strong></span>' +
          '</div>' +
        '</nav>' +
        '<main style="padding:16px; max-width:1400px; margin:0 auto; width:100%">' +
          '<div class="room-layout">' +
            '<div class="video-area">' +
              '<div class="video-grid solo" id="video-grid">' +
                '<div class="video-tile" id="local-tile">' +
                  '<video id="local-video" autoplay muted playsinline></video>' +
                  '<div class="tile-label"><i class="fa-solid fa-circle" style="color:var(--green); font-size:0.5rem"></i> Tú (' + window.UI.escapeHtml(user.display_name) + ')</div>' +
                '</div>' +
              '</div>' +
              '<div class="room-controls">' +
                '<button class="ctrl-btn" id="toggle-audio" title="Micrófono"><i class="fa-solid fa-microphone"></i></button>' +
                '<button class="ctrl-btn" id="toggle-video" title="Cámara"><i class="fa-solid fa-video"></i></button>' +
                '<button class="ctrl-btn leave" id="leave-btn"><i class="fa-solid fa-phone-slash"></i> Salir</button>' +
              '</div>' +
            '</div>' +
            '<div class="sidebar-panel">' +
              '<div class="sidebar-tabs">' +
                '<button class="sidebar-tab active" data-tab="info"><i class="fa-solid fa-circle-info"></i> Sala</button>' +
                '<button class="sidebar-tab" data-tab="chat"><i class="fa-solid fa-comments"></i> Chat</button>' +
              '</div>' +
              '<div class="sidebar-body">' +
                '<div id="tab-info" class="room-info-panel">' +
                  '<p class="muted" style="margin:0">Comparte este código con tu compañero:</p>' +
                  '<div class="room-code-display">' + window.UI.escapeHtml(roomCode) + '</div>' +
                  '<button class="btn-bl btn-blue btn-sm" id="copy-link" style="width:100%"><i class="fa-solid fa-copy"></i> Copiar enlace</button>' +
                  '<div style="margin-top:18px"><div style="font-weight:800; margin-bottom:6px">Participantes</div><div id="participants-list" class="muted">Cargando…</div></div>' +
                '</div>' +
                '<div id="tab-chat" style="display:none; flex-direction:column; flex:1; overflow:hidden">' +
                  '<div class="chat-messages" id="chat-messages"></div>' +
                  '<form class="chat-input-bar" id="chat-form">' +
                    '<input type="text" id="chat-input" placeholder="Escribe un mensaje…" maxlength="2000" autocomplete="off">' +
                    '<button type="submit" class="btn-bl btn-green btn-sm"><i class="fa-solid fa-paper-plane"></i></button>' +
                  '</form>' +
                '</div>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</main>' +
      '</div>';

    var grid = container.querySelector('#video-grid');
    var localVideo = container.querySelector('#local-video');
    var participantsList = container.querySelector('#participants-list');
    var chatMessages = container.querySelector('#chat-messages');
    var chatForm = container.querySelector('#chat-form');
    var chatInput = container.querySelector('#chat-input');

    // Tabs
    container.querySelectorAll('.sidebar-tab').forEach(function (t) {
      t.addEventListener('click', function () {
        container.querySelectorAll('.sidebar-tab').forEach(function (x) { x.classList.remove('active'); });
        t.classList.add('active');
        var which = t.dataset.tab;
        container.querySelector('#tab-info').style.display = which === 'info' ? '' : 'none';
        container.querySelector('#tab-chat').style.display = which === 'chat' ? 'flex' : 'none';
      });
    });

    // Copy link
    container.querySelector('#copy-link').addEventListener('click', function () {
      var link = window.location.origin + window.location.pathname + '#/room/' + roomCode;
      navigator.clipboard.writeText(link).then(function () {
        window.UI.notify('Enlace copiado al portapapeles', 'success');
      }).catch(function () {
        window.UI.notify('No se pudo copiar', 'error');
      });
    });

    // Get user media
    try {
      localStream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      localVideo.srcObject = localStream;
    } catch (err) {
      window.UI.notify('No se pudo acceder a la cámara/micrófono: ' + err.message, 'error');
      // continue without media
      localStream = new MediaStream();
    }

    // Join room via API first
    try {
      await window.API.post('api/rooms/' + roomCode + '/join', {});
    } catch (err) {
      window.UI.notify(err.message || 'No se pudo unir a la sala', 'error');
      setTimeout(function () { window.Router.navigate('dashboard'); }, 1500);
      return;
    }

    // Load chat history
    try {
      var roomData = await window.API.get('api/rooms/' + roomCode);
      var msgs = await window.API.get('api/rooms/' + roomData.id + '/messages');
      msgs.forEach(addChatMessage);
    } catch (e) { /* ignore */ }

    // Connect socket — must use the proxy base path so the WS hits /run/<id>/socket.io/
    var basePath = (document.querySelector('base') && document.querySelector('base').getAttribute('href')) || '/';
    if (!basePath.endsWith('/')) basePath += '/';
    // Use polling-only: the reverse proxy may not allow WebSocket upgrade.
    // Polling works over plain HTTPS and is fine for WebRTC signaling
    // (actual A/V traffic is peer-to-peer, not through the socket).
    socket = io({
      path: basePath + 'socket.io',
      transports: ['polling'],
      upgrade: false
    });

    socket.on('connect', function () {
      socket.emit('room:join', { roomCode: roomCode });
    });

    socket.on('room:error', function (data) {
      window.UI.notify(data.message || 'Error de sala', 'error');
    });

    socket.on('room:joined', function (data) {
      updateParticipants();
      // Initiate offers to existing peers
      data.peers.forEach(function (peer) { createPeer(peer, true); });
    });

    socket.on('peer:joined', function (peer) {
      // Existing peer waits for incoming offer
      createPeer({ socketId: peer.socketId, userId: peer.userId, displayName: peer.displayName, avatarColor: peer.avatarColor }, false);
      window.UI.notify(peer.displayName + ' se ha unido 👋', 'info');
    });

    socket.on('peer:left', function (data) {
      removePeer(data.socketId);
    });

    socket.on('webrtc:offer', async function (data) {
      var peer = peers[data.from];
      if (!peer) {
        peer = createPeer({ socketId: data.from, userId: data.user.id, displayName: data.user.displayName, avatarColor: data.user.avatarColor }, false);
      }
      try {
        await peer.pc.setRemoteDescription(new RTCSessionDescription(data.sdp));
        var answer = await peer.pc.createAnswer();
        await peer.pc.setLocalDescription(answer);
        socket.emit('webrtc:answer', { to: data.from, sdp: answer });
      } catch (err) { console.error('offer handle err', err); }
    });

    socket.on('webrtc:answer', async function (data) {
      var peer = peers[data.from];
      if (!peer) return;
      try { await peer.pc.setRemoteDescription(new RTCSessionDescription(data.sdp)); } catch (e) { console.error(e); }
    });

    socket.on('webrtc:ice', async function (data) {
      var peer = peers[data.from];
      if (!peer || !data.candidate) return;
      try { await peer.pc.addIceCandidate(new RTCIceCandidate(data.candidate)); } catch (e) { /* ignore */ }
    });

    socket.on('chat:message', function (msg) {
      addChatMessage(msg);
    });

    function createPeer(info, initiator) {
      if (peers[info.socketId]) return peers[info.socketId];
      var pc = new RTCPeerConnection(ICE_CONFIG);
      var peer = { pc: pc, user: info, videoEl: null };
      peers[info.socketId] = peer;

      // add local tracks
      if (localStream) {
        localStream.getTracks().forEach(function (t) { pc.addTrack(t, localStream); });
      }

      pc.onicecandidate = function (e) {
        if (e.candidate) socket.emit('webrtc:ice', { to: info.socketId, candidate: e.candidate });
      };

      pc.ontrack = function (e) {
        attachRemoteStream(info, e.streams[0]);
      };

      pc.onconnectionstatechange = function () {
        if (pc.connectionState === 'failed' || pc.connectionState === 'closed') {
          removePeer(info.socketId);
        }
      };

      if (initiator) {
        pc.createOffer().then(function (offer) {
          return pc.setLocalDescription(offer).then(function () {
            socket.emit('webrtc:offer', { to: info.socketId, sdp: offer });
          });
        }).catch(function (err) { console.error('offer err', err); });
      }

      addPeerTile(info);
      updateParticipants();
      return peer;
    }

    function addPeerTile(info) {
      if (document.getElementById('tile-' + info.socketId)) return;
      var tile = document.createElement('div');
      tile.className = 'video-tile';
      tile.id = 'tile-' + info.socketId;
      tile.innerHTML =
        '<video autoplay playsinline></video>' +
        '<div class="tile-label"><i class="fa-solid fa-circle" style="color:' + info.avatarColor + '; font-size:0.5rem"></i> ' + window.UI.escapeHtml(info.displayName) + '</div>';
      grid.appendChild(tile);
      grid.classList.remove('solo');
      peers[info.socketId].videoEl = tile.querySelector('video');
    }

    function attachRemoteStream(info, stream) {
      var peer = peers[info.socketId];
      if (peer && peer.videoEl) peer.videoEl.srcObject = stream;
    }

    function removePeer(socketId) {
      var peer = peers[socketId];
      if (!peer) return;
      try { peer.pc.close(); } catch (e) {}
      delete peers[socketId];
      var tile = document.getElementById('tile-' + socketId);
      if (tile) tile.remove();
      if (Object.keys(peers).length === 0) grid.classList.add('solo');
      updateParticipants();
    }

    function updateParticipants() {
      var items = [
        '<div style="display:flex; align-items:center; gap:8px; padding:6px 0">' +
          window.UI.avatar(user.display_name, user.avatar_color, 'sm') +
          '<div><div style="font-weight:800; font-size:0.9rem">' + window.UI.escapeHtml(user.display_name) + ' (tú)</div></div>' +
        '</div>'
      ];
      Object.keys(peers).forEach(function (sid) {
        var p = peers[sid].user;
        items.push('<div style="display:flex; align-items:center; gap:8px; padding:6px 0">' +
          window.UI.avatar(p.displayName, p.avatarColor, 'sm') +
          '<div><div style="font-weight:800; font-size:0.9rem">' + window.UI.escapeHtml(p.displayName) + '</div></div>' +
        '</div>');
      });
      participantsList.innerHTML = items.join('');
    }

    function addChatMessage(msg) {
      var own = msg.user_id === user.id;
      var el = document.createElement('div');
      el.className = 'chat-msg' + (own ? ' own' : '');
      el.innerHTML =
        (!own ? window.UI.avatar(msg.display_name, msg.avatar_color, 'sm') : '') +
        '<div class="chat-msg-bubble">' +
          (!own ? '<div class="sender" style="color:' + (msg.avatar_color || '#58CC02') + '">' + window.UI.escapeHtml(msg.display_name) + '</div>' : '') +
          '<div>' + window.UI.escapeHtml(msg.content) + '</div>' +
        '</div>';
      chatMessages.appendChild(el);
      chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    chatForm.addEventListener('submit', function (e) {
      e.preventDefault();
      var content = chatInput.value.trim();
      if (!content) return;
      socket.emit('chat:send', { content: content });
      chatInput.value = '';
    });

    container.querySelector('#toggle-audio').addEventListener('click', function () {
      audioOn = !audioOn;
      localStream.getAudioTracks().forEach(function (t) { t.enabled = audioOn; });
      this.classList.toggle('off', !audioOn);
      this.innerHTML = '<i class="fa-solid ' + (audioOn ? 'fa-microphone' : 'fa-microphone-slash') + '"></i>';
      socket.emit('media:state', { audio: audioOn, video: videoOn });
    });

    container.querySelector('#toggle-video').addEventListener('click', function () {
      videoOn = !videoOn;
      localStream.getVideoTracks().forEach(function (t) { t.enabled = videoOn; });
      this.classList.toggle('off', !videoOn);
      this.innerHTML = '<i class="fa-solid ' + (videoOn ? 'fa-video' : 'fa-video-slash') + '"></i>';
      socket.emit('media:state', { audio: audioOn, video: videoOn });
    });

    async function leaveRoom() {
      if (ended) return;
      ended = true;
      try {
        var roomData = await window.API.get('api/rooms/' + roomCode);
        if (roomData) await window.API.post('api/rooms/' + roomData.id + '/end', {});
      } catch (e) {}
      cleanup();
      window.Router.navigate('dashboard');
    }

    container.querySelector('#leave-btn').addEventListener('click', leaveRoom);

    function cleanup() {
      Object.keys(peers).forEach(function (sid) { try { peers[sid].pc.close(); } catch (e) {} });
      peers = {};
      if (localStream) { localStream.getTracks().forEach(function (t) { t.stop(); }); }
      if (socket) { try { socket.disconnect(); } catch (e) {} }
    }

    // return cleanup so the router calls it on navigation
    return cleanup;
  }

  window.Router.register('room', render);
})();
