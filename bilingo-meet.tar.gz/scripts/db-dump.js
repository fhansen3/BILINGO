#!/usr/bin/env node
// Genera un dump SQL (CREATE TABLE + INSERT) de la base de datos del proyecto.
// Salida: bilingo-meet-dump.sql en la raíz del proyecto.
const fs = require('fs');
const path = require('path');
const mysql = require('mysql2/promise');

function envOrDie(name) {
  const v = process.env[name];
  if (!v) {
    console.error(`Missing env var ${name}`);
    process.exit(1);
  }
  return v;
}

function esc(v) {
  if (v === null || v === undefined) return 'NULL';
  if (typeof v === 'number') return Number.isFinite(v) ? String(v) : 'NULL';
  if (typeof v === 'boolean') return v ? '1' : '0';
  if (v instanceof Date) {
    const pad = (n) => String(n).padStart(2, '0');
    return `'${v.getUTCFullYear()}-${pad(v.getUTCMonth() + 1)}-${pad(v.getUTCDate())} ${pad(v.getUTCHours())}:${pad(v.getUTCMinutes())}:${pad(v.getUTCSeconds())}'`;
  }
  if (Buffer.isBuffer(v)) return `0x${v.toString('hex')}`;
  if (typeof v === 'object') {
    return `'${JSON.stringify(v).replace(/\\/g, '\\\\').replace(/'/g, "\\'")}'`;
  }
  const s = String(v)
    .replace(/\\/g, '\\\\')
    .replace(/'/g, "\\'")
    .replace(/\n/g, '\\n')
    .replace(/\r/g, '\\r')
    .replace(/\x1a/g, '\\Z')
    .replace(/\x00/g, '\\0');
  return `'${s}'`;
}

(async () => {
  const conn = await mysql.createConnection({
    host: envOrDie('DB_HOST'),
    port: Number(envOrDie('DB_PORT')),
    user: envOrDie('DB_USER'),
    password: envOrDie('DB_PASSWORD'),
    database: envOrDie('DB_NAME'),
    multipleStatements: true,
  });

  const dbName = process.env.DB_NAME;
  const outPath = path.join(process.cwd(), 'bilingo-meet-dump.sql');
  const out = fs.createWriteStream(outPath, { encoding: 'utf8' });

  out.write(`-- BiLingo Meet DB dump\n-- Database: ${dbName}\n-- Generated: ${new Date().toISOString()}\n\n`);
  out.write(`SET FOREIGN_KEY_CHECKS=0;\nSET NAMES utf8mb4;\nSET SQL_MODE='NO_AUTO_VALUE_ON_ZERO';\n\n`);

  // Tablas
  const [tables] = await conn.query(
    `SELECT TABLE_NAME FROM information_schema.TABLES
       WHERE TABLE_SCHEMA = ? AND TABLE_TYPE='BASE TABLE'
       ORDER BY TABLE_NAME`,
    [dbName]
  );

  for (const t of tables) {
    const table = t.TABLE_NAME;
    out.write(`-- ----------------------------------------------------\n-- Table: ${table}\n-- ----------------------------------------------------\n`);
    out.write(`DROP TABLE IF EXISTS \`${table}\`;\n`);
    const [createRows] = await conn.query(`SHOW CREATE TABLE \`${table}\``);
    const createSql = createRows[0]['Create Table'];
    out.write(`${createSql};\n\n`);

    // Datos
    const [rows] = await conn.query(`SELECT * FROM \`${table}\``);
    if (rows.length > 0) {
      const cols = Object.keys(rows[0]);
      const colList = cols.map((c) => `\`${c}\``).join(',');
      const BATCH = 100;
      for (let i = 0; i < rows.length; i += BATCH) {
        const slice = rows.slice(i, i + BATCH);
        const values = slice
          .map((r) => `(${cols.map((c) => esc(r[c])).join(',')})`)
          .join(',\n  ');
        out.write(`INSERT INTO \`${table}\` (${colList}) VALUES\n  ${values};\n`);
      }
      out.write('\n');
    }
  }

  // Vistas (si hubiera)
  const [views] = await conn.query(
    `SELECT TABLE_NAME FROM information_schema.VIEWS WHERE TABLE_SCHEMA = ?`,
    [dbName]
  );
  for (const v of views) {
    const [r] = await conn.query(`SHOW CREATE VIEW \`${v.TABLE_NAME}\``);
    out.write(`-- View: ${v.TABLE_NAME}\nDROP VIEW IF EXISTS \`${v.TABLE_NAME}\`;\n${r[0]['Create View']};\n\n`);
  }

  out.write(`SET FOREIGN_KEY_CHECKS=1;\n`);
  out.end();

  await new Promise((res) => out.on('finish', res));
  await conn.end();

  const stat = fs.statSync(outPath);
  console.log(`Dump OK: ${outPath} (${stat.size} bytes, ${tables.length} tables, ${views.length} views)`);
})().catch((err) => {
  console.error('Dump failed:', err);
  process.exit(1);
});
