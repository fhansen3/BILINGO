'use strict';

const path = require('path');
const express = require('express');
const cookieParser = require('cookie-parser');
const http = require('http');
const { Server } = require('socket.io');

const env = require('./config/env');
const routes = require('./routes');
const { errorHandler } = require('./middleware/errors');
const { attachSockets } = require('./sockets');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: true, credentials: true } });

app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/api', routes);

app.get('/healthz', (req, res) => res.json({ ok: true }));

// SPA fallback (Express 5 compatible)
app.use((req, res, next) => {
  if (req.method !== 'GET') return next();
  if (req.path.startsWith('/api/') || req.path.startsWith('/socket.io/')) return next();
  if (path.extname(req.path)) return next();
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.use(errorHandler);

attachSockets(io);

server.listen(env.port, () => {
  console.log(`BiLingo Meet running on port ${env.port}`);
});
