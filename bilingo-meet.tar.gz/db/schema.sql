-- =====================================================================
-- BiLingo Meet — Schema only (no data)
-- =====================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- Parent table: users
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password_hash` VARCHAR(255) NOT NULL,
  `display_name` VARCHAR(100) NOT NULL,
  `bio` TEXT,
  `avatar_color` VARCHAR(20) DEFAULT '#58CC02',
  `native_language` VARCHAR(50),
  `learning_language` VARCHAR(50),
  `proficiency_level` ENUM('beginner','intermediate','advanced','fluent') DEFAULT 'beginner',
  `country` VARCHAR(80),
  `role` ENUM('user','admin') DEFAULT 'user',
  `status` ENUM('active','banned','suspended') DEFAULT 'active',
  `is_online` TINYINT(1) DEFAULT 0,
  `last_seen` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_users_native_language` (`native_language`),
  INDEX `idx_users_is_online` (`is_online`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Rooms (depends on users)
CREATE TABLE IF NOT EXISTS `rooms` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `room_code` VARCHAR(20) NOT NULL UNIQUE,
  `name` VARCHAR(120),
  `host_id` INT NOT NULL,
  `guest_id` INT,
  `language_focus` VARCHAR(50),
  `topic` VARCHAR(150),
  `max_participants` TINYINT DEFAULT 2,
  `is_public` TINYINT(1) DEFAULT 1,
  `status` ENUM('waiting','open','active','ended','closed') NOT NULL DEFAULT 'waiting',
  `started_at` TIMESTAMP NULL,
  `ended_at` TIMESTAMP NULL,
  `duration_seconds` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_rooms_host_id` (`host_id`),
  INDEX `idx_rooms_guest_id` (`guest_id`),
  INDEX `idx_rooms_status` (`status`),
  CONSTRAINT `fk_rooms_host` FOREIGN KEY (`host_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rooms_guest` FOREIGN KEY (`guest_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Messages (depends on rooms + users)
CREATE TABLE IF NOT EXISTS `messages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `room_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `content` TEXT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_messages_room_id` (`room_id`),
  INDEX `idx_messages_user_id` (`user_id`),
  CONSTRAINT `fk_messages_room` FOREIGN KEY (`room_id`) REFERENCES `rooms`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_messages_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Session history (depends on rooms + users)
CREATE TABLE IF NOT EXISTS `session_history` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `room_id` INT NOT NULL,
  `user_id` INT NOT NULL,
  `partner_id` INT,
  `duration_seconds` INT DEFAULT 0,
  `rating` TINYINT,
  `notes` TEXT,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_sh_room_id` (`room_id`),
  INDEX `idx_sh_user_id` (`user_id`),
  INDEX `idx_sh_partner_id` (`partner_id`),
  CONSTRAINT `fk_sh_room` FOREIGN KEY (`room_id`) REFERENCES `rooms`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sh_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_sh_partner` FOREIGN KEY (`partner_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Reports (depends on users + rooms)
CREATE TABLE IF NOT EXISTS `reports` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `reporter_id` INT NOT NULL,
  `reported_user_id` INT NOT NULL,
  `room_id` INT,
  `reason` VARCHAR(100) NOT NULL,
  `details` TEXT,
  `status` ENUM('pending','reviewed','resolved','dismissed','actioned') NOT NULL DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `reviewed_at` TIMESTAMP NULL,
  INDEX `idx_reports_reporter_id` (`reporter_id`),
  INDEX `idx_reports_reported_user_id` (`reported_user_id`),
  INDEX `idx_reports_room_id` (`room_id`),
  INDEX `idx_reports_status` (`status`),
  CONSTRAINT `fk_reports_reporter` FOREIGN KEY (`reporter_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_reports_reported` FOREIGN KEY (`reported_user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_reports_room` FOREIGN KEY (`room_id`) REFERENCES `rooms`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;
