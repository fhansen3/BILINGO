'use strict';

const { verify } = require('../utils/jwt');
const db = require('../config/db');
const roomsService = require('../services/rooms.service');

function parseCookies(cookieHeader) {
  const out = {};
  if (!cookieHeader) return out;
  cookieHeader.split(';').forEach(p => {
    const idx = p.indexOf('=');
    if (idx === -1) return;
    out[p.slice(0, idx).trim()] = decodeURIComponent(p.slice(idx + 1).trim());
  });
  return out;
}

function attachSockets(io) {
  io.use(async (socket, next) => {
    try {
      const cookies = parseCookies(socket.handshake.headers.cookie || '');
      const token = cookies.token || socket.handshake.auth?.token;
      if (!token) return next(new Error('No token'));
      const payload = verify(token);
      if (!payload) return next(new Error('Invalid token'));
      const users = await db.query('SELECT id, display_name, avatar_color, role FROM users WHERE id = ?', [payload.id]);
      if (!users.length) return next(new Error('User not found'));
      socket.user = users[0];
      next();
    } catch (err) {
      next(err);
    }
  });

  io.on('connection', async (socket) => {
    const user = socket.user;
    await db.query('UPDATE users SET is_online = 1, last_seen = NOW() WHERE id = ?', [user.id]);
    io.emit('presence:update', { userId: user.id, online: true });

    socket.on('room:join', async ({ roomCode }) => {
      try {
        const room = await roomsService.getRoomByCode(roomCode);
        if (!room) return socket.emit('room:error', { message: 'Room not found' });

        socket.join(`room:${room.id}`);
        socket.data.roomId = room.id;
        socket.data.roomCode = roomCode;

        // Notify others in the room
        socket.to(`room:${room.id}`).emit('peer:joined', {
          userId: user.id,
          displayName: user.display_name,
          avatarColor: user.avatar_color,
          socketId: socket.id
        });

        // Send list of existing peers to the new joiner
        const sockets = await io.in(`room:${room.id}`).fetchSockets();
        const peers = sockets
          .filter(s => s.id !== socket.id)
          .map(s => ({
            userId: s.user.id,
            displayName: s.user.display_name,
            avatarColor: s.user.avatar_color,
            socketId: s.id
          }));
        socket.emit('room:joined', { room, peers });
      } catch (err) {
        socket.emit('room:error', { message: err.message });
      }
    });

    // WebRTC signaling — forward to specific peer
    socket.on('webrtc:offer', ({ to, sdp }) => {
      io.to(to).emit('webrtc:offer', { from: socket.id, sdp, user: { id: user.id, displayName: user.display_name, avatarColor: user.avatar_color } });
    });
    socket.on('webrtc:answer', ({ to, sdp }) => {
      io.to(to).emit('webrtc:answer', { from: socket.id, sdp });
    });
    socket.on('webrtc:ice', ({ to, candidate }) => {
      io.to(to).emit('webrtc:ice', { from: socket.id, candidate });
    });

    // Chat
    socket.on('chat:send', async ({ content }) => {
      if (!socket.data.roomId || !content) return;
      const trimmed = String(content).slice(0, 2000);
      try {
        const msg = await roomsService.addMessage(socket.data.roomId, user.id, trimmed);
        io.to(`room:${socket.data.roomId}`).emit('chat:message', msg);
      } catch (err) {
        socket.emit('chat:error', { message: err.message });
      }
    });

    // Media state (mute/camera)
    socket.on('media:state', (state) => {
      if (!socket.data.roomId) return;
      socket.to(`room:${socket.data.roomId}`).emit('media:state', {
        socketId: socket.id,
        userId: user.id,
        ...state
      });
    });

    socket.on('room:leave', () => {
      if (socket.data.roomId) {
        socket.to(`room:${socket.data.roomId}`).emit('peer:left', { socketId: socket.id, userId: user.id });
        socket.leave(`room:${socket.data.roomId}`);
        socket.data.roomId = null;
      }
    });

    socket.on('disconnect', async () => {
      if (socket.data.roomId) {
        socket.to(`room:${socket.data.roomId}`).emit('peer:left', { socketId: socket.id, userId: user.id });
      }
      // Set offline if user has no other sockets
      const sockets = await io.fetchSockets();
      const stillOnline = sockets.some(s => s.user && s.user.id === user.id);
      if (!stillOnline) {
        await db.query('UPDATE users SET is_online = 0, last_seen = NOW() WHERE id = ?', [user.id]);
        io.emit('presence:update', { userId: user.id, online: false });
      }
    });
  });
}

module.exports = { attachSockets };
